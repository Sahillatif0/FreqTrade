from datetime import datetime
from functools import reduce
import numpy as np
import pandas as pd
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import (
    IStrategy,
    merge_informative_pair,
    stoploss_from_open,
)


class SolConfluenceSpot(IStrategy):
    """
    Intraday Multi-Confluence Spot Strategy (15m Execution, 1h Macro Filter).
    
    Architecture:
    - 1h Macro Filter: 50 EMA slope & BTC alignment.
    - Setup A: Dynamic 15m Fair Value Gap (FVG) retest above VWAP.
    - Setup B: Intraday VWAP Reclaim with Micro Market Structure Shift (MSS).
    - Risk & Execution: Fixed -1.8% hard stop, 2-tier profit locking, staged ROI ladder.
    - Built-in Protections: Cooldown after exits + StoplossGuard against drawdown streaks.
    """

    INTERFACE_VERSION = 3

    # Primary execution and informative macro intervals
    timeframe = "15m"
    informative_timeframe = "1h"
    can_short: bool = False

    # Staged ROI Ladder tailored for multi-hour spot expansion
    minimal_roi = {
        "0": 0.048,    # 4.8% on immediate momentum spikes
        "60": 0.032,   # 3.2% after 1 hour
        "180": 0.024,  # 2.4% after 3 hours
        "360": 0.018   # 1.8% minimum take-profit floor (preserves R:R)
    }

    # Baseline hard stop loss (-1.80%)
    stoploss = -0.018

    # Prevent premature trailing stops; manage profit-locking exclusively via custom_stoploss
    trailing_stop = False
    use_custom_stoploss = True

    # Limit orders for entries/exits to minimize maker/taker fee drag
    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    startup_candle_count: int = 120

    @property
    def protections(self):
        """
        Circuit breakers to prevent consecutive stopouts during sharp macro corrections.
        """
        return [
            {
                "method": "CooldownPeriod",
                "stop_duration_candles": 4  # Wait 1 hour (4 x 15m) after exiting before re-entering
            },
            {
                "method": "StoplossGuard",
                "lookback_period_candles": 32, # Look back over the last 8 hours
                "trade_limit": 2,              # If 2 stop losses are triggered
                "stop_duration_candles": 16,   # Pause trading across all pairs for 4 hours
                "only_per_pair": False
            }
        ]

    def informative_pairs(self):
        """
        Pulls 1h candles for target whitelist pairs and the BTC benchmark.
        """
        pairs = self.dp.current_whitelist()
        informative = [(pair, self.informative_timeframe) for pair in pairs]
        informative.append(("BTC/USDT", self.informative_timeframe))
        return informative

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Multi-tier profit locking:
        - Only locks profit after significant expansion to prevent whipsaw exits.
        - Returning 1 keeps the baseline -1.8% hard stop anchored to the entry price.
        """
        # Tier 2: Up +3.5% -> Lock in +2.0% profit
        if current_profit >= 0.035:
            return stoploss_from_open(0.020, current_profit)

        # Tier 1: Up +2.2% -> Move stop to +0.5% (safely clears 0.20% roundtrip spot fees)
        if current_profit >= 0.022:
            return stoploss_from_open(0.005, current_profit)

        # Retain original hard stop without creeping upward on routine noise
        return 1

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # -------------------------------------------------------------
        # 1. Informative Macro (1h) - Target Pair & BTC Benchmark
        # -------------------------------------------------------------
        informative_pair = self.dp.get_pair_dataframe(
            pair=metadata["pair"], timeframe=self.informative_timeframe
        )
        if not informative_pair.empty:
            informative_pair["ema_50"] = ta.EMA(informative_pair, timeperiod=50)
            # 50 EMA must be pointing upward over the last 3 hours (positive slope)
            informative_pair["ema_50_slope"] = (
                informative_pair["ema_50"] - informative_pair["ema_50"].shift(3)
            ) > 0
            dataframe = merge_informative_pair(
                dataframe, informative_pair, self.timeframe, self.informative_timeframe, ffill=True
            )

        btc_1h = self.dp.get_pair_dataframe(pair="BTC/USDT", timeframe=self.informative_timeframe)
        if not btc_1h.empty:
            btc_1h["btc_ema_50"] = ta.EMA(btc_1h, timeperiod=50)
            btc_1h["btc_uptrend"] = btc_1h["close"] > btc_1h["btc_ema_50"]
            dataframe = merge_informative_pair(
                dataframe, btc_1h, self.timeframe, self.informative_timeframe, ffill=True
            )

        # -------------------------------------------------------------
        # 2. Base 15m Indicators
        # -------------------------------------------------------------
        dataframe["ema_20"] = ta.EMA(dataframe, timeperiod=20)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()

        # -------------------------------------------------------------
        # 3. Anchored Session VWAP & Standard Deviation Bands
        # -------------------------------------------------------------
        date_series = pd.to_datetime(dataframe["date"])
        day_group = date_series.dt.floor("D")

        typical_price = (dataframe["high"] + dataframe["low"] + dataframe["close"]) / 3.0
        pv = typical_price * dataframe["volume"]

        dataframe["cum_pv"] = pv.groupby(day_group).cumsum()
        dataframe["cum_vol"] = dataframe["volume"].groupby(day_group).cumsum()
        dataframe["vwap"] = dataframe["cum_pv"] / np.where(dataframe["cum_vol"] == 0, 1, dataframe["cum_vol"])

        # Standard deviation bands (±1.5σ)
        price_diff_sq = ((typical_price - dataframe["vwap"]) ** 2) * dataframe["volume"]
        cum_diff_sq = price_diff_sq.groupby(day_group).cumsum()
        dataframe["vwap_std"] = np.sqrt(cum_diff_sq / np.where(dataframe["cum_vol"] == 0, 1, dataframe["cum_vol"]))
        dataframe["vwap_upper"] = dataframe["vwap"] + (1.5 * dataframe["vwap_std"])

        # Upper boundary cap to avoid longing into overextended conditions (+0.75σ)
        dataframe["exhaustion_cap"] = dataframe["vwap"] + (0.75 * dataframe["vwap_std"])

        # -------------------------------------------------------------
        # 4. Bullish Fair Value Gap (FVG) Detection
        # -------------------------------------------------------------
        fvg_gap = dataframe["low"] - dataframe["high"].shift(2)
        dataframe["fvg_bullish"] = (
            (fvg_gap > 0) &
            (dataframe["close"].shift(1) > dataframe["open"].shift(1)) &
            (dataframe["close"] > dataframe["ema_20"])
        ).astype(int)
        dataframe["fvg_recent"] = dataframe["fvg_bullish"].rolling(window=4).max()

        # Candle confirmation
        dataframe["is_green_candle"] = dataframe["close"] > dataframe["open"]

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "enter_long"] = 0
        dataframe.loc[:, "enter_tag"] = ""

        # Global Macro & Trend Filters
        macro_btc = dataframe.get("btc_uptrend_1h", pd.Series(True, index=dataframe.index)) == True
        macro_asset = (
            (dataframe.get("ema_50_slope_1h", pd.Series(True, index=dataframe.index)) == True) &
            (dataframe["close"] > dataframe.get("ema_50_1h", dataframe["close"]))
        )
        trend_15m = dataframe["ema_20"] > dataframe["ema_50"]
        volume_ok = dataframe["volume"] > (dataframe["volume_sma"] * 1.10)
        rsi_sweet_spot = dataframe["rsi"].between(40, 60)
        not_exhausted = dataframe["close"] <= dataframe["exhaustion_cap"]

        base_rules = macro_btc & macro_asset & trend_15m & volume_ok & rsi_sweet_spot & not_exhausted

        # -------------------------------------------------------------
        # Trigger A: Institutional FVG Retest
        # -------------------------------------------------------------
        trigger_fvg = (
            base_rules &
            (dataframe["fvg_recent"] == 1) &
            (dataframe["close"] >= dataframe["vwap"]) &
            (dataframe["is_green_candle"])
        )
        dataframe.loc[trigger_fvg, "enter_long"] = 1
        dataframe.loc[trigger_fvg, "enter_tag"] = "entry_fvg_retest"

        # -------------------------------------------------------------
        # Trigger B: VWAP Reclaim with Micro Market Structure Shift (MSS)
        # -------------------------------------------------------------
        swept_below_vwap = dataframe["low"].rolling(window=3).min() < dataframe["vwap"]
        closed_above_vwap = dataframe["close"] > dataframe["vwap"]
        micro_mss = dataframe["close"] > dataframe["high"].shift(1)

        trigger_vwap_reclaim = (
            base_rules &
            swept_below_vwap &
            closed_above_vwap &
            micro_mss &
            dataframe["is_green_candle"]
        )
        dataframe.loc[trigger_vwap_reclaim, "enter_long"] = 1
        dataframe.loc[trigger_vwap_reclaim, "enter_tag"] = "entry_vwap_reclaim"

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # Technical exit signal: Overbought exhaustion beyond upper VWAP band with bearish reversal
        conditions.append(dataframe["close"] >= dataframe["vwap_upper"])
        conditions.append(dataframe["rsi"] > 75)
        conditions.append(dataframe["close"] < dataframe["open"])

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                "exit_long"
            ] = 1

        return dataframe