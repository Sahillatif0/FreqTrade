from datetime import datetime, timedelta
from functools import reduce
import numpy as np
import pandas as pd
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import (
    IStrategy,
    merge_informative_pair,
    stoploss_from_open,
)


class SolConfluenceSpot(IStrategy):
    """
    Multi-Confluence Intraday Spot Strategy (15m Execution, 1h Macro Filter).
    Combines:
    - 1h Trend Filter (BTC/USDT & SOL/USDT EMAs)
    - Session Anchored VWAP with standard deviation bands
    - 15m Fair Value Gap (FVG) / Imbalance detection
    - RSI Pullback + Volume confirmation
    - Custom Profit-Locking Stoploss (Break-even at +1.2%)
    """

    INTERFACE_VERSION = 3

    timeframe = "15m"
    informative_timeframe = "1h"
    can_short: bool = False

    # Staged ROI targets tailored for multi-hour spot expansion
    minimal_roi = {
        "0": 0.048,
        "60": 0.032,
        "180": 0.024,
        "360": 0.018
    }

    # Initial hard stop loss (-2.5%)
    stoploss = -0.018

    # Enable custom dynamic stop loss for break-even and profit locking
    use_custom_stoploss = True
    
    trailing_stop = False

    # Order execution settings (Limit orders to minimize maker/taker fee drag)
    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    startup_candle_count: int = 120

    def informative_pairs(self):
        """
        Fetches 1h data for the target pair as well as BTC/USDT to enforce macro alignment.
        """
        pairs = self.dp.current_whitelist()
        informative = [(pair, self.informative_timeframe) for pair in pairs]
        informative.append(("BTC/USDT", self.informative_timeframe))
        return informative

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Only adjust stoploss once trade is comfortably in profit (+2.4%).
        Moves stop to +0.4% (locks in green and pays exchange fees).
        """
        if current_profit >= 0.035:
            # If up +3.5%, trail at +1.8%
            return stoploss_from_open(0.020, current_profit)
        elif current_profit >= 0.022:
            # If up +2.4%, move stop to +0.4%
            return stoploss_from_open(0.005, current_profit)

        # Otherwise leave the -2.4% hard stop intact
        return 1

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # -------------------------------------------------------------
        # 1. Informative Macro (1h) - SOL & BTC
        # -------------------------------------------------------------
        informative_pair = self.dp.get_pair_dataframe(
            pair=metadata["pair"], timeframe=self.informative_timeframe
        )
        if not informative_pair.empty:
            informative_pair["ema_20"] = ta.EMA(informative_pair, timeperiod=20)
            informative_pair["ema_50"] = ta.EMA(informative_pair, timeperiod=50)
            # Slope: EMA 50 must be pointing upward over last 3 hours
            informative_pair["ema_50_slope"] = (
                informative_pair["ema_50"] - informative_pair["ema_50"].shift(3)
            ) > 0
            dataframe = merge_informative_pair(
                dataframe, informative_pair, self.timeframe, self.informative_timeframe, ffill=True
            )

        btc_1h = self.dp.get_pair_dataframe(pair="BTC/USDT", timeframe=self.informative_timeframe)
        if not btc_1h.empty:
            btc_1h["btc_ema_50"] = ta.EMA(btc_1h, timeperiod=50)
            btc_1h["btc_uptrend"] = btc_1h["close"] > btc_1h["btc_ema_50"]
            dataframe = merge_informative_pair(
                dataframe, btc_1h, self.timeframe, self.informative_timeframe, ffill=True
            )

        # -------------------------------------------------------------
        # 2. Base 15m Indicators
        # -------------------------------------------------------------
        dataframe["ema_20"] = ta.EMA(dataframe, timeperiod=20)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()

        # -------------------------------------------------------------
        # 3. Anchored Session VWAP & Bands
        # -------------------------------------------------------------
        date_series = pd.to_datetime(dataframe["date"])
        day_group = date_series.dt.floor("D")

        typical_price = (dataframe["high"] + dataframe["low"] + dataframe["close"]) / 3.0
        pv = typical_price * dataframe["volume"]

        dataframe["cum_pv"] = pv.groupby(day_group).cumsum()
        dataframe["cum_vol"] = dataframe["volume"].groupby(day_group).cumsum()
        dataframe["vwap"] = dataframe["cum_pv"] / np.where(dataframe["cum_vol"] == 0, 1, dataframe["cum_vol"])

        price_diff_sq = ((typical_price - dataframe["vwap"]) ** 2) * dataframe["volume"]
        cum_diff_sq = price_diff_sq.groupby(day_group).cumsum()
        dataframe["vwap_std"] = np.sqrt(cum_diff_sq / np.where(dataframe["cum_vol"] == 0, 1, dataframe["cum_vol"]))
        dataframe["vwap_lower"] = dataframe["vwap"] - (1.5 * dataframe["vwap_std"])
        dataframe["vwap_upper"] = dataframe["vwap"] + (1.5 * dataframe["vwap_std"])

        # -------------------------------------------------------------
        # 4. Filtered Institutional FVG (with Displacement)
        # -------------------------------------------------------------
        candle2_body = (dataframe["close"].shift(1) - dataframe["open"].shift(1)).abs()
        has_displacement = candle2_body > (dataframe["atr"].shift(1) * 0.9)
        fvg_gap = dataframe["low"] - dataframe["high"].shift(2)

        dataframe["fvg_bullish"] = (
            (fvg_gap > (dataframe["atr"] * 0.2)) &  # Meaningful gap size
            has_displacement &                      # Impulsive displacement candle
            (dataframe["close"].shift(1) > dataframe["open"].shift(1))
        ).astype(int)
        
        dataframe["fvg_recent"] = dataframe["fvg_bullish"].rolling(window=4).max()

        # -------------------------------------------------------------
        # 5. Bullish Candle Rejection Geometry
        # -------------------------------------------------------------
        total_candle_range = dataframe["high"] - dataframe["low"]
        lower_wick = np.minimum(dataframe["open"], dataframe["close"]) - dataframe["low"]
        # Demand lower wick rejection (at least 30% of total candle range)
        dataframe["has_lower_wick"] = (lower_wick / np.where(total_candle_range == 0, 1, total_candle_range)) > 0.30
        dataframe["is_green_candle"] = dataframe["close"] > dataframe["open"]

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "enter_long"] = 0
        dataframe.loc[:, "enter_tag"] = ""

        # Global Baseline Filters:
        macro_btc = dataframe.get("btc_uptrend_1h", pd.Series(True, index=dataframe.index)) == True
        macro_sol = (
            (dataframe.get("ema_50_slope_1h", pd.Series(True, index=dataframe.index)) == True) &
            (dataframe["close"] > dataframe.get("ema_50_1h", dataframe["close"]))
        )
        trend_15m = dataframe["ema_20"] > dataframe["ema_50"]
        volume_ok = dataframe["volume"] > (dataframe["volume_sma"] * 1.15)
        rsi_sweet_spot = dataframe["rsi"].between(42, 58)

        base_rules = macro_btc & macro_sol & trend_15m & volume_ok & rsi_sweet_spot

        # -------------------------------------------------------------
        # Trigger A: FVG Retest Bounce
        # -------------------------------------------------------------
        trigger_fvg = (
            base_rules &
            (dataframe["fvg_recent"] == 1) &
            (dataframe["close"] >= dataframe["vwap"]) &
            (dataframe["is_green_candle"])
        )
        dataframe.loc[trigger_fvg, "enter_long"] = 1
        dataframe.loc[trigger_fvg, "enter_tag"] = "entry_fvg_retest"

        # -------------------------------------------------------------
        # Trigger B: VWAP Lower Band Reclaim with Wick Rejection
        # -------------------------------------------------------------
        trigger_vwap_reclaim = (
            base_rules &
            (dataframe["low"] <= dataframe["vwap_lower"]) &
            (dataframe["close"] > dataframe["ema_20"]) &
            (dataframe["has_lower_wick"] | dataframe["is_green_candle"])
        )
        dataframe.loc[trigger_vwap_reclaim, "enter_long"] = 1
        dataframe.loc[trigger_vwap_reclaim, "enter_tag"] = "entry_vwap_sweep"

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # Exit signal: Overbought exhaustion beyond upper VWAP band with bearish reversal
        conditions.append(dataframe["close"] >= dataframe["vwap_upper"])
        conditions.append(dataframe["rsi"] > 75)
        conditions.append(dataframe["close"] < dataframe["open"])

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                "exit_long"
            ] = 1

        return dataframe
    
    # def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
    #             current_profit: float, **kwargs):
    #     # Calculate trade duration in minutes
    #     trade_dur = (current_time - trade.open_date_utc).total_seconds() / 60

    #     # If open > 3.5 hours (14 candles) and still struggling below breakeven, cut it
    #     if trade_dur > 210 and current_profit < 0.005:
    #         return "time_exit_stagnant"
            
    #     return None    