from datetime import datetime, timedelta
from functools import reduce
import numpy as np
import pandas as pd
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import (
    IStrategy,
    merge_informative_pair,
    stoploss_from_open,
)


class SolConfluenceSpot(IStrategy):
    """
    Multi-Confluence Intraday Spot Strategy (15m Execution, 1h Macro Filter).
    Combines:
    - 1h Trend Filter (BTC/USDT & SOL/USDT EMAs)
    - Session Anchored VWAP with standard deviation bands
    - 15m Fair Value Gap (FVG) / Imbalance detection
    - RSI Pullback + Volume confirmation
    - Custom Profit-Locking Stoploss (Break-even at +1.2%)
    """

    INTERFACE_VERSION = 3

    timeframe = "15m"
    informative_timeframe = "1h"
    can_short: bool = False

    # Staged ROI targets tailored for multi-hour spot expansion
    minimal_roi = {
    "0": 0.038,    # 4.8% on quick spikes
    "30": 0.024,   # 3.2% after 30 mins
    "90": 0.016,   # 2.2% after 1.5 hours
    "180": 0.010   # 1.4% after 3 hours
}

    # Initial hard stop loss (-2.5%)
    stoploss = -0.024

    # Enable custom dynamic stop loss for break-even and profit locking
    use_custom_stoploss = True
    
    trailing_stop = False

    # Order execution settings (Limit orders to minimize maker/taker fee drag)
    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    startup_candle_count: int = 120

    def informative_pairs(self):
        """
        Fetches 1h data for the target pair as well as BTC/USDT to enforce macro alignment.
        """
        pairs = self.dp.current_whitelist()
        informative = [(pair, self.informative_timeframe) for pair in pairs]
        informative.append(("BTC/USDT", self.informative_timeframe))
        return informative

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Only adjust stoploss once trade is comfortably in profit (+2.4%).
        Moves stop to +0.4% (locks in green and pays exchange fees).
        """
        if current_profit >= 0.035:
            # If up +3.5%, trail at +1.8%
            return stoploss_from_open(0.018, current_profit)
        elif current_profit >= 0.024:
            # If up +2.4%, move stop to +0.4%
            return stoploss_from_open(0.004, current_profit)

        # Otherwise leave the -2.4% hard stop intact
        return 1

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # -------------------------------------------------------------
        # 1. Informative Macro Indicators (1h)
        # -------------------------------------------------------------
        # Target Pair 1h
        informative_pair = self.dp.get_pair_dataframe(
            pair=metadata["pair"], timeframe=self.informative_timeframe
        )
        if not informative_pair.empty:
            informative_pair["ema_50"] = ta.EMA(informative_pair, timeperiod=50)
            informative_pair["ema_200"] = ta.EMA(informative_pair, timeperiod=200)
            dataframe = merge_informative_pair(
                dataframe, informative_pair, self.timeframe, self.informative_timeframe, ffill=True
            )

        # BTC/USDT 1h Benchmark
        btc_1h = self.dp.get_pair_dataframe(pair="BTC/USDT", timeframe=self.informative_timeframe)
        if not btc_1h.empty:
            btc_1h["btc_ema_50"] = ta.EMA(btc_1h, timeperiod=50)
            dataframe = merge_informative_pair(
                dataframe, btc_1h, self.timeframe, self.informative_timeframe, ffill=True
            )

        # -------------------------------------------------------------
        # 2. Base Indicators (15m)
        # -------------------------------------------------------------
        dataframe["ema_20"] = ta.EMA(dataframe, timeperiod=20)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()

        # -------------------------------------------------------------
        # 3. Session Anchored VWAP & Standard Deviation Bands
        # -------------------------------------------------------------
        # Reset VWAP daily at 00:00 UTC
        date_series = pd.to_datetime(dataframe["date"])
        day_group = date_series.dt.floor("D")

        typical_price = (dataframe["high"] + dataframe["low"] + dataframe["close"]) / 3.0
        pv = typical_price * dataframe["volume"]

        dataframe["cum_pv"] = pv.groupby(day_group).cumsum()
        dataframe["cum_vol"] = dataframe["volume"].groupby(day_group).cumsum()
        dataframe["vwap"] = dataframe["cum_pv"] / np.where(dataframe["cum_vol"] == 0, 1, dataframe["cum_vol"])

        # VWAP standard deviation bands
        price_diff_sq = ((typical_price - dataframe["vwap"]) ** 2) * dataframe["volume"]
        cum_diff_sq = price_diff_sq.groupby(day_group).cumsum()
        dataframe["vwap_std"] = np.sqrt(cum_diff_sq / np.where(dataframe["cum_vol"] == 0, 1, dataframe["cum_vol"]))
        dataframe["vwap_lower"] = dataframe["vwap"] - (1.5 * dataframe["vwap_std"])
        dataframe["vwap_upper"] = dataframe["vwap"] + (1.5 * dataframe["vwap_std"])

        # -------------------------------------------------------------
        # 4. Bullish Fair Value Gap (FVG) Detection
        # Candle 1 High < Candle 3 Low with displacement in Candle 2
        # -------------------------------------------------------------
        dataframe["fvg_bullish"] = (
            (dataframe["low"] > dataframe["high"].shift(2)) & 
            (dataframe["close"].shift(1) > dataframe["open"].shift(1))
        ).astype(int)
        # Identify if price has retraced into recent FVG within last 3 bars
        dataframe["fvg_recent"] = dataframe["fvg_bullish"].rolling(window=3).max()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # 1. Macro Regime: BTC must be above 1h 50 EMA (market tailwind)
        if "btc_ema_50_1h" in dataframe.columns and "close_1h" in dataframe.columns:
            conditions.append(dataframe["close_1h"] > dataframe["btc_ema_50_1h"])

        # 2. Structural Alignment: 1h SOL trend is bullish (Price > 1h 50 EMA)
        if "ema_50_1h" in dataframe.columns:
            conditions.append(dataframe["close"] > dataframe["ema_50_1h"])

        # 3. 15m Alignment: EMA 20 > EMA 50
        conditions.append(dataframe["ema_20"] > dataframe["ema_50"])

        # 4. Value / Liquidity Reclaim Confluence:
        # Either:
        # (A) Retesting recent Bullish FVG and holding above VWAP
        # OR
        # (B) Bouncing off the VWAP Lower Band (-1.5σ) and reclaiming the 20 EMA
        setup_a = (dataframe["fvg_recent"] == 1) & (dataframe["close"] >= dataframe["vwap"])
        setup_b = (dataframe["low"] <= dataframe["vwap_lower"]) & (dataframe["close"] > dataframe["ema_20"])
        conditions.append(setup_a | setup_b)

        # 5. Momentum Reset: RSI is out of oversold territory without being overbought (40 to 58)
        conditions.append(dataframe["rsi"].between(40, 58))

        # 6. Volume Validation: Trading activity at least 1.1x the 20-period baseline
        conditions.append(dataframe["volume"] > (dataframe["volume_sma"] * 1.1))

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                "enter_long"
            ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # Exit signal: Overbought exhaustion beyond upper VWAP band with bearish reversal
        conditions.append(dataframe["close"] >= dataframe["vwap_upper"])
        conditions.append(dataframe["rsi"] > 75)
        conditions.append(dataframe["close"] < dataframe["open"])

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                "exit_long"
            ] = 1

        return dataframe
    
    # def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
    #             current_profit: float, **kwargs):
    #     # Calculate trade duration in minutes
    #     trade_dur = (current_time - trade.open_date_utc).total_seconds() / 60

    #     # If open > 3.5 hours (14 candles) and still struggling below breakeven, cut it
    #     if trade_dur > 210 and current_profit < 0.005:
    #         return "time_exit_stagnant"
            
    #     return None    