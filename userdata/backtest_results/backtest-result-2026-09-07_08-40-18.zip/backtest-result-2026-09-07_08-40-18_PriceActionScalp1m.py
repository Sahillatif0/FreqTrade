from datetime import datetime
from functools import reduce
import numpy as np
import pandas as pd
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import (
    IStrategy,
    merge_informative_pair,
    stoploss_from_open,
)


class PriceActionScalp1m(IStrategy):
    """
    PriceActionScalp1m:
    High-Frequency 1m Price Action & BOS Scalping Engine
    
    Architecture:
    1. 15m Macro Bias: Trend direction via EMA 50/200.
    2. 5m Intermediate Structure: Break of Structure (BOS) & Fair Value Gap (FVG).
    3. 1m Base Execution: Micro-displacement, VWAP reclaim, EMA 9/21 cross, Volume push.
    4. Rapid ROI ladder (0.7% - 2.5%) & tight 0.9% risk management for frequent trade turnover.
    """

    INTERFACE_VERSION = 3

    timeframe = "1m"
    informative_timeframe_15m = "15m"
    informative_timeframe_1h = "1h"
    can_short: bool = False

    # Expanded Profit Ladder: Overcomes 0.2% round-trip exchange fees with 1.2% - 3.8% targets
    minimal_roi = {
        "0": 0.038,    # 3.8% peak runner
        "25": 0.024,   # 2.4% after 25 mins
        "50": 0.016,   # 1.6% after 50 mins
        "100": 0.012   # 1.2% floor target after 100 mins
    }

    # Precision 1.1% hard stop-loss
    stoploss = -0.011

    trailing_stop = False
    use_custom_stoploss = True

    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    startup_candle_count: int = 250

    @property
    def protections(self):
        return [
            {
                "method": "CooldownPeriod",
                "stop_duration_candles": 10  # Wait 10 mins after exiting a pair
            },
            {
                "method": "StoplossGuard",
                "lookback_period_candles": 60,
                "trade_limit": 2,
                "stop_duration_candles": 45,
                "only_per_pair": True
            }
        ]

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        informative = []
        for pair in pairs:
            informative.append((pair, self.informative_timeframe_15m))
            informative.append((pair, self.informative_timeframe_1h))
        # Market-wide BTC Guardrail on 1h
        informative.append(("BTC/USDT", self.informative_timeframe_1h))
        return informative

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Asymmetric runner profit lock:
        - At +2.8% profit -> Lock in +2.0%
        - At +1.8% profit -> Lock in +1.1%
        - At +0.9% profit -> Lock in +0.35% (secures trade well above round-trip fees)
        """
        if current_profit >= 0.028:
            return stoploss_from_open(0.020, current_profit)

        if current_profit >= 0.018:
            return stoploss_from_open(0.011, current_profit)

        if current_profit >= 0.009:
            return stoploss_from_open(0.0035, current_profit)

        return 1

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # -------------------------------------------------------------
        # 1. Macro Trend (1h): Asset Trend & Market-wide BTC Trend
        # -------------------------------------------------------------
        pair_1h = self.dp.get_pair_dataframe(pair=metadata["pair"], timeframe=self.informative_timeframe_1h)
        if not pair_1h.empty:
            pair_1h["ema_50"] = ta.EMA(pair_1h, timeperiod=50)
            pair_1h["ema_200"] = ta.EMA(pair_1h, timeperiod=200)
            pair_1h["macro_bull"] = (
                (pair_1h["close"] > pair_1h["ema_50"]) &
                (pair_1h["ema_50"] > pair_1h["ema_200"])
            )
            dataframe = merge_informative_pair(
                dataframe, pair_1h, self.timeframe, self.informative_timeframe_1h, ffill=True
            )

        btc_1h = self.dp.get_pair_dataframe(pair="BTC/USDT", timeframe=self.informative_timeframe_1h)
        if not btc_1h.empty:
            btc_1h["btc_ema_50"] = ta.EMA(btc_1h, timeperiod=50)
            btc_1h["btc_ema_200"] = ta.EMA(btc_1h, timeperiod=200)
            btc_1h["btc_bull"] = (
                (btc_1h["close"] > btc_1h["btc_ema_50"]) &
                (btc_1h["btc_ema_50"] > btc_1h["btc_ema_200"])
            )
            dataframe = merge_informative_pair(
                dataframe, btc_1h, self.timeframe, self.informative_timeframe_1h, ffill=True
            )

        # -------------------------------------------------------------
        # 2. Intermediate Structure (15m): BOS & Momentum
        # -------------------------------------------------------------
        pair_15m = self.dp.get_pair_dataframe(pair=metadata["pair"], timeframe=self.informative_timeframe_15m)
        if not pair_15m.empty:
            pair_15m["ema_50"] = ta.EMA(pair_15m, timeperiod=50)
            pair_15m["swing_high"] = pair_15m["high"].shift(1).rolling(window=8).max()
            pair_15m["bos_break"] = pair_15m["close"] > pair_15m["swing_high"]
            pair_15m["bos_recent"] = pair_15m["bos_break"].rolling(window=6).max()
            pair_15m["adx"] = ta.ADX(pair_15m, timeperiod=14)
            pair_15m["trend_15m_bull"] = pair_15m["close"] > pair_15m["ema_50"]

            dataframe = merge_informative_pair(
                dataframe, pair_15m, self.timeframe, self.informative_timeframe_15m, ffill=True
            )

        # -------------------------------------------------------------
        # 3. Micro Base Frame (1m): High-Frequency Execution
        # -------------------------------------------------------------
        dataframe["ema_9"] = ta.EMA(dataframe, timeperiod=9)
        dataframe["ema_21"] = ta.EMA(dataframe, timeperiod=21)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()

        # Session VWAP (12-hour session rolling VWAP)
        typical_price = (dataframe["high"] + dataframe["low"] + dataframe["close"]) / 3.0
        pv = typical_price * dataframe["volume"]
        window_1m = 720
        cum_pv = pv.rolling(window=window_1m, min_periods=1).sum()
        cum_vol = dataframe["volume"].rolling(window=window_1m, min_periods=1).sum()
        dataframe["vwap"] = cum_pv / np.where(cum_vol == 0, 1, cum_vol)
        dataframe["vwap_upper"] = dataframe["vwap"] + (1.85 * dataframe["atr"])

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "enter_long"] = 0
        dataframe.loc[:, "enter_tag"] = ""

        # Step 1: 1h Macro Trend (Pair & BTC/USDT)
        btc_col = [c for c in dataframe.columns if c.startswith("btc_bull_")]
        macro_btc = dataframe[btc_col[0]] == True if btc_col else pd.Series(True, index=dataframe.index)

        macro_col = [c for c in dataframe.columns if c.startswith("macro_bull_") and "BTC" not in c]
        macro_asset = dataframe[macro_col[0]] == True if macro_col else pd.Series(True, index=dataframe.index)

        trend_aligned = macro_btc & macro_asset

        # Step 2: 15m Confirmed Break of Structure + Trend
        bos_confirmed = dataframe.get("bos_recent_15m", pd.Series(True, index=dataframe.index)) == 1
        trend_15m = dataframe.get("trend_15m_bull_15m", pd.Series(True, index=dataframe.index)) == True
        adx_15m = dataframe.get("adx_15m", pd.Series(20, index=dataframe.index)) > 18

        structure_ok = bos_confirmed & trend_15m & adx_15m

        # Step 3: 1m Micro Execution Entry with genuine volume push & momentum
        scalp_reclaim = (
            trend_aligned &
            structure_ok &
            (dataframe["close"] > dataframe["ema_50"]) &
            (dataframe["close"] > dataframe["ema_9"]) &
            (dataframe["ema_9"] > dataframe["ema_21"]) &
            (dataframe["close"] <= dataframe["ema_9"] * 1.0025) &  # Close to moving average
            (dataframe["close"] >= dataframe["vwap"]) &
            (dataframe["close"] > dataframe["open"]) &
            (dataframe["volume"] > dataframe["volume_sma"] * 1.40) &
            (dataframe["rsi"].between(50, 65))
        )

        dataframe.loc[scalp_reclaim, "enter_long"] = 1
        dataframe.loc[scalp_reclaim, "enter_tag"] = "1m_fvg_bos_scalp"

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # Overextension above 1m VWAP band + RSI exhaustion
        conditions.append(dataframe["close"] >= dataframe["vwap_upper"])
        conditions.append(dataframe["rsi"] > 80)

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                "exit_long"
            ] = 1

        return dataframe
