from datetime import datetime
from functools import reduce
import numpy as np
import pandas as pd
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import (
    IStrategy,
    merge_informative_pair,
    stoploss_from_open,
)


class PriceActionScalp1m(IStrategy):
    """
    PriceActionScalp1m:
    High-Frequency 1m Price Action & BOS Scalping Engine
    
    Architecture:
    1. 15m Macro Bias: Trend direction via EMA 50/200.
    2. 5m Intermediate Structure: Break of Structure (BOS) & Fair Value Gap (FVG).
    3. 1m Base Execution: Micro-displacement, VWAP reclaim, EMA 9/21 cross, Volume push.
    4. Rapid ROI ladder (0.7% - 2.5%) & tight 0.9% risk management for frequent trade turnover.
    """

    INTERFACE_VERSION = 3

    timeframe = "1m"
    informative_timeframe_5m = "5m"
    informative_timeframe_15m = "15m"
    can_short: bool = False

    # Rapid Scalping ROI Ladder
    minimal_roi = {
        "0": 0.025,    # 2.5% instant runner spike
        "10": 0.015,   # 1.5% target after 10 mins
        "25": 0.010,   # 1.0% target after 25 mins
        "45": 0.007    # 0.7% quick exit after 45 mins
    }

    # Tight 0.9% hard stoploss for 1m scalping
    stoploss = -0.009

    trailing_stop = False
    use_custom_stoploss = True

    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    startup_candle_count: int = 150

    @property
    def protections(self):
        return [
            {
                "method": "CooldownPeriod",
                "stop_duration_candles": 3  # Wait 3 mins after exit
            },
            {
                "method": "StoplossGuard",
                "lookback_period_candles": 45,
                "trade_limit": 3,
                "stop_duration_candles": 15,
                "only_per_pair": True
            }
        ]

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        informative = []
        for pair in pairs:
            informative.append((pair, self.informative_timeframe_5m))
            informative.append((pair, self.informative_timeframe_15m))
        return informative

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Micro-trailing stop to protect scalper gains:
        - At +1.8% profit -> Lock in +1.2%
        - At +1.2% profit -> Lock in +0.7%
        - At +0.8% profit -> Lock in +0.4% (break-even+)
        """
        if current_profit >= 0.018:
            return stoploss_from_open(0.012, current_profit)

        if current_profit >= 0.012:
            return stoploss_from_open(0.007, current_profit)

        if current_profit >= 0.008:
            return stoploss_from_open(0.004, current_profit)

        return 1

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # -------------------------------------------------------------
        # 1. Macro Trend (15m): Clean directional bias
        # -------------------------------------------------------------
        pair_15m = self.dp.get_pair_dataframe(pair=metadata["pair"], timeframe=self.informative_timeframe_15m)
        if not pair_15m.empty:
            pair_15m["ema_50"] = ta.EMA(pair_15m, timeperiod=50)
            pair_15m["ema_200"] = ta.EMA(pair_15m, timeperiod=200)
            pair_15m["macro_bull"] = pair_15m["close"] > pair_15m["ema_50"]
            dataframe = merge_informative_pair(
                dataframe, pair_15m, self.timeframe, self.informative_timeframe_15m, ffill=True
            )

        # -------------------------------------------------------------
        # 2. Intermediate Structure (5m): BOS & FVG
        # -------------------------------------------------------------
        pair_5m = self.dp.get_pair_dataframe(pair=metadata["pair"], timeframe=self.informative_timeframe_5m)
        if not pair_5m.empty:
            pair_5m["swing_high"] = pair_5m["high"].shift(1).rolling(window=6).max()
            pair_5m["bos_break"] = pair_5m["close"] > pair_5m["swing_high"]
            pair_5m["bos_recent"] = pair_5m["bos_break"].rolling(window=8).max()

            # 5m Fair Value Gap
            fvg = pair_5m["low"] - pair_5m["high"].shift(2)
            pair_5m["fvg_bullish"] = ((fvg > 0) & (pair_5m["close"].shift(1) > pair_5m["open"].shift(1))).astype(int)
            pair_5m["fvg_active"] = pair_5m["fvg_bullish"].rolling(window=6).max()

            dataframe = merge_informative_pair(
                dataframe, pair_5m, self.timeframe, self.informative_timeframe_5m, ffill=True
            )

        # -------------------------------------------------------------
        # 3. Micro Base Frame (1m): High-Frequency Precision Triggers
        # -------------------------------------------------------------
        dataframe["ema_9"] = ta.EMA(dataframe, timeperiod=9)
        dataframe["ema_21"] = ta.EMA(dataframe, timeperiod=21)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()

        # Session VWAP (12-hour session rolling VWAP)
        typical_price = (dataframe["high"] + dataframe["low"] + dataframe["close"]) / 3.0
        pv = typical_price * dataframe["volume"]
        window_1m = 720
        cum_pv = pv.rolling(window=window_1m, min_periods=1).sum()
        cum_vol = dataframe["volume"].rolling(window=window_1m, min_periods=1).sum()
        dataframe["vwap"] = cum_pv / np.where(cum_vol == 0, 1, cum_vol)
        dataframe["vwap_upper"] = dataframe["vwap"] + (1.65 * dataframe["atr"])

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "enter_long"] = 0
        dataframe.loc[:, "enter_tag"] = ""

        # Step 1: Macro Trend (15m close above 50 EMA)
        macro_col = [c for c in dataframe.columns if c.startswith("macro_bull_")]
        macro_ok = dataframe[macro_col[0]] == True if macro_col else pd.Series(True, index=dataframe.index)

        # Step 2: Intermediate Structure (5m BOS or 5m FVG active)
        bos_col = [c for c in dataframe.columns if c.startswith("bos_recent_")]
        fvg_col = [c for c in dataframe.columns if c.startswith("fvg_active_")]
        bos_ok = dataframe[bos_col[0]] == 1 if bos_col else pd.Series(True, index=dataframe.index)
        fvg_ok = dataframe[fvg_col[0]] == 1 if fvg_col else pd.Series(True, index=dataframe.index)
        structure_ok = bos_ok | fvg_ok

        # Step 3: 1m Micro Execution Entry
        scalp_reclaim = (
            macro_ok &
            structure_ok &
            (dataframe["close"] > dataframe["ema_9"]) &
            (dataframe["ema_9"] > dataframe["ema_21"]) &
            (dataframe["close"] >= dataframe["vwap"]) &
            (dataframe["close"] > dataframe["open"]) &
            (dataframe["volume"] > dataframe["volume_sma"] * 1.15) &
            (dataframe["rsi"].between(45, 68))
        )

        dataframe.loc[scalp_reclaim, "enter_long"] = 1
        dataframe.loc[scalp_reclaim, "enter_tag"] = "1m_fvg_bos_scalp"

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # Overextension above 1m VWAP band + RSI exhaustion
        conditions.append(dataframe["close"] >= dataframe["vwap_upper"])
        conditions.append(dataframe["rsi"] > 75)

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                "exit_long"
            ] = 1

        return dataframe
