from datetime import datetime
from functools import reduce
import numpy as np
import pandas as pd
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import (
    IStrategy,
    merge_informative_pair,
    stoploss_from_open,
)


class SolScalp5m(IStrategy):
    """
    SolScalp5m (v2 Optimized): High-Winrate 5-Minute Micro Scalping Strategy.
    
    Tuned directly from empirical backtest diagnosis:
    1. Replaced static -1.5% hard stop with ATR-dynamic stoploss (0.8x ATR).
    2. Enhanced 5m_breakout filter with EMA slope and volume strength to eliminate false breakout traps.
    3. Added 15m RSI macro filter.
    4. Tightened ROI target steps to capture intraday scalps before reversals.
    """

    INTERFACE_VERSION = 3

    timeframe = "5m"
    informative_timeframe = "15m"
    can_short: bool = False

    # Scalper ROI Ladder: Fast take-profits for 5m chart
    minimal_roi = {
        "0": 0.022,    # 2.2% immediate spike target
        "10": 0.015,   # 1.5% target after 10 mins
        "30": 0.010,   # 1.0% target after 30 mins
        "60": 0.006    # 0.6% profit floor after 1 hour
    }

    # Baseline Hard Stop loss (Default floor, overridden dynamically by ATR)
    stoploss = -0.012

    trailing_stop = False
    use_custom_stoploss = True

    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    startup_candle_count: int = 100

    @property
    def protections(self):
        return [
            {
                "method": "CooldownPeriod",
                "stop_duration_candles": 4  # Wait 20 mins (4 x 5m) after exiting a trade
            },
            {
                "method": "StoplossGuard",
                "lookback_period_candles": 24, # Look back over 2 hours
                "trade_limit": 2,              # If 2 stoplosses hit within 2h
                "stop_duration_candles": 24,   # Pause trading for 2 hours
                "only_per_pair": False
            }
        ]

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        informative = [(pair, self.informative_timeframe) for pair in pairs]
        informative.append(("BTC/USDT", self.informative_timeframe))
        return informative

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Dynamic ATR-Anchored Stoploss & Profit Locking.
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(dataframe) > 0:
            last_candle = dataframe.iloc[-1]
            atr = last_candle.get("atr", 0)
            open_rate = trade.open_rate

            # If ATR is available, use dynamic 0.85x ATR stoploss (capped at -1.5%)
            if atr > 0:
                atr_stop_ratio = -min(0.015, max(0.008, (1.0 * atr) / open_rate))
            else:
                atr_stop_ratio = -0.012
        else:
            atr_stop_ratio = -0.012

        # Tier 3: Up +1.8% -> Lock in +1.0%
        if current_profit >= 0.018:
            return stoploss_from_open(0.010, current_profit)

        # Tier 2: Up +1.0% -> Lock in +0.5%
        if current_profit >= 0.010:
            return stoploss_from_open(0.005, current_profit)

        # Tier 1: Up +0.6% -> Move to Breakeven (+0.2% to cover fees)
        if current_profit >= 0.006:
            return stoploss_from_open(0.002, current_profit)

        return atr_stop_ratio

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # -------------------------------------------------------------
        # 1. Informative Macro Filter (15m)
        # -------------------------------------------------------------
        informative_pair = self.dp.get_pair_dataframe(
            pair=metadata["pair"], timeframe=self.informative_timeframe
        )
        if not informative_pair.empty:
            informative_pair["ema_50"] = ta.EMA(informative_pair, timeperiod=50)
            informative_pair["rsi_15m"] = ta.RSI(informative_pair, timeperiod=14)
            informative_pair["trend_15m"] = (
                (informative_pair["close"] > informative_pair["ema_50"]) &
                (informative_pair["rsi_15m"] > 45)
            )
            dataframe = merge_informative_pair(
                dataframe, informative_pair, self.timeframe, self.informative_timeframe, ffill=True
            )

        btc_15m = self.dp.get_pair_dataframe(pair="BTC/USDT", timeframe=self.informative_timeframe)
        if not btc_15m.empty:
            btc_15m["btc_ema_50"] = ta.EMA(btc_15m, timeperiod=50)
            btc_15m["btc_uptrend_15m"] = btc_15m["close"] > btc_15m["btc_ema_50"]
            dataframe = merge_informative_pair(
                dataframe, btc_15m, self.timeframe, self.informative_timeframe, ffill=True
            )

        # -------------------------------------------------------------
        # 2. Base 5m Indicators
        # -------------------------------------------------------------
        dataframe["ema_9"] = ta.EMA(dataframe, timeperiod=9)
        dataframe["ema_21"] = ta.EMA(dataframe, timeperiod=21)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()

        # EMA Slopes to ensure momentum alignment
        dataframe["ema_9_slope"] = dataframe["ema_9"] - dataframe["ema_9"].shift(2)
        dataframe["ema_21_slope"] = dataframe["ema_21"] - dataframe["ema_21"].shift(2)

        # Fast Stochastic RSI (14, 3, 3)
        fastk, fastd = ta.STOCHRSI(dataframe["close"], timeperiod=14, fastk_period=3, fastd_period=3)
        dataframe["stoch_k"] = fastk
        dataframe["stoch_d"] = fastd

        # -------------------------------------------------------------
        # 3. Rolling Intraday VWAP (Smooth 24h Window)
        # -------------------------------------------------------------
        typical_price = (dataframe["high"] + dataframe["low"] + dataframe["close"]) / 3.0
        pv = typical_price * dataframe["volume"]
        window_5m = 288  # 24 hours of 5m candles
        
        cum_pv = pv.rolling(window=window_5m, min_periods=1).sum()
        cum_vol = dataframe["volume"].rolling(window=window_5m, min_periods=1).sum()
        dataframe["vwap"] = cum_pv / np.where(cum_vol == 0, 1, cum_vol)

        # Volatility Bands
        dataframe["vwap_upper"] = dataframe["vwap"] + (1.1 * dataframe["atr"])
        dataframe["vwap_lower"] = dataframe["vwap"] - (1.1 * dataframe["atr"])

        # Candle Analysis
        dataframe["is_green"] = dataframe["close"] > dataframe["open"]

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "enter_long"] = 0
        dataframe.loc[:, "enter_tag"] = ""

        # Global Macro Alignment (15m BTC & 15m Asset uptrends)
        macro_btc = dataframe.get("btc_uptrend_15m_15m", pd.Series(True, index=dataframe.index)) == True
        macro_asset = dataframe.get("trend_15m_15m", pd.Series(True, index=dataframe.index)) == True
        
        # Require strong volume expansion (1.4x SMA)
        volume_spike = dataframe["volume"] > (dataframe["volume_sma"] * 1.40)
        base_filters = macro_btc & macro_asset & volume_spike

        # -------------------------------------------------------------
        # Setup 1: High-Confluence Momentum Breakout
        # -------------------------------------------------------------
        ema_bullish = (dataframe["ema_9"] > dataframe["ema_21"]) & (dataframe["ema_21"] > dataframe["ema_50"])
        ema_slopes_positive = (dataframe["ema_9_slope"] > 0) & (dataframe["ema_21_slope"] > 0)
        vwap_support = dataframe["close"] > dataframe["vwap"]
        rsi_bullish = dataframe["rsi"].between(52, 67)

        setup_breakout = (
            base_filters &
            ema_bullish &
            ema_slopes_positive &
            vwap_support &
            rsi_bullish &
            dataframe["is_green"]
        )
        dataframe.loc[setup_breakout, "enter_long"] = 1
        dataframe.loc[setup_breakout, "enter_tag"] = "5m_breakout"

        # -------------------------------------------------------------
        # Setup 2: Dip Buy / VWAP Bounce (StochRSI Oversold Reclaim)
        # -------------------------------------------------------------
        volume_dip_ok = dataframe["volume"] > (dataframe["volume_sma"] * 1.15)
        base_dip_filters = macro_btc & macro_asset & volume_dip_ok

        stoch_oversold = (dataframe["stoch_k"].shift(1) < 20) | (dataframe["stoch_d"].shift(1) < 20)
        stoch_cross = (dataframe["stoch_k"] > dataframe["stoch_d"]) & (dataframe["stoch_k"].shift(1) <= dataframe["stoch_d"].shift(1))
        near_vwap_or_ema = (
            (dataframe["low"] <= dataframe["vwap_upper"]) &
            (dataframe["close"] >= dataframe["vwap_lower"]) &
            (dataframe["close"] >= dataframe["ema_50"])
        )
        rsi_oversold_recovery = dataframe["rsi"].between(40, 56)

        setup_dip_buy = (
            base_dip_filters &
            stoch_oversold &
            stoch_cross &
            near_vwap_or_ema &
            rsi_oversold_recovery &
            dataframe["is_green"]
        )
        dataframe.loc[setup_dip_buy, "enter_long"] = 1
        dataframe.loc[setup_dip_buy, "enter_tag"] = "5m_dip_bounce"

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # Exit 1: StochRSI Overbought Cross Down
        stoch_overbought = (dataframe["stoch_k"] > 82) & (dataframe["stoch_k"] < dataframe["stoch_d"])
        
        # Exit 2: Price overextended past upper VWAP band
        vwap_overextended = dataframe["close"] > dataframe["vwap_upper"]

        conditions.append(stoch_overbought | vwap_overextended)
        conditions.append(dataframe["rsi"] > 68)

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                "exit_long"
            ] = 1

        return dataframe
